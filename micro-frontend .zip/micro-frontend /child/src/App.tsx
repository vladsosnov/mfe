import React from "react";

export const App: React.FC<{}> = () => {
  return <h2>Child MFE App</h2>;
};





