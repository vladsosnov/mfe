declare module "childApp/childApp" {
  export function mount(el: HTMLElement): void;
}
